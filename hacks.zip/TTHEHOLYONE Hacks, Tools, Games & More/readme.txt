TTHEHOLYONES MODS&GAMES&TOOLS&MORE

Thank you for purchasing my school tools. 
It means alot to me and I really thank you for it. 
Please use are tools responsibly and please listen to your teachers!!
I know are tools can be tempting but if you do disobey your teachers you can't blame it on me!
These tools should be used on your own time at home


HOW TO DOWNLOAD THE TOOLS TO YOUR SCHOOL CHROMEBOOK!!!
1: Open Google Chrome
2: Click the Searchbar
3: Paste this website into the searchbar "chrome://bookmarks/"
4: Click enter
5: Now that you are on the website you are getting really close
6: On the website there will be a searchbar that says search bookmarks next to the searchbar will be three dots click on the three dots and click "IMPORT BOOKMARKS"
7: You will have FILES APP open so then open the TTHEHOLYONE Hacks, Tools, Games & More Folder
8: Open Hacks Download(readme.txt for help) Folder
9: Click on the HTML FILE
10: Now let it load and watch my TTHEHOLYONE bookmark folder go onto your chrome
11: Now drag the folder you see onto your bookmarks bar
12: If you dont have a bookmarks bar because it is disabled for some reason go to settings on chrome
13: Search up bookmarks
14: Look for the option that says "View Bookmarks" enable it!



Some of our rules are:
**Do not snitch if you get caught and play it cool to try to avoid causing further problems this would probably me more of the blooket hacks and I dont know how many times I have to say this do not use any of the get cash on the gamemodes or anything that would get you #1 automatically as you WILL get caught as it would be sus. I recommend to use it during your freetime or with friends NOT with teachers games.**
**Do not SHARE( If you are caught sharing the hacks will be deleted prompto )**
**Please do not use them dumb like trying to watch a movie in class or using the blooket hacks and getting BILLIONS of coins as it sounds really really fun you can use them in a private game with friends but not reccomended for Teachers Games and if you do decide otherwise you can not blame me for using them inappropiately**
**If you get caught anytime any how using any of our tools maliciously or during class when a teacher says no and if its not on your free time again you cant blame it on me as I TOLD you not to.**










If one of you purchasers snitch(tools will be removed) or if a teacher does end up seeing this:

These tools are all made by me or gathered from different websites by me. Whenever someone wants these tools I tell them not to use it malicously or during school. I cant stop them from doing that. These tools are all for fun on their free time. Some of these tools actually helps kids by giving them useful websites or teaching them things. While I understand completely that they were doing something wrong I told them they shouldnt use them malicously and they shouldnt do this at school. 
