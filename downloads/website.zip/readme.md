
# HolyUnblocked

This is a website which unblocks multiple games, plugins, etc.. This website can not be seen by GoGuardian if you download and use the site locally. It can be seen if you use my replit domain. 

## Authors

- [@TTheHolyOne](https://www.github.com/ttheholyone)


## Features

- GoGuardian can't see it if used locally
- Plenty of plugins
- Chatroom
- Unblocked Websites
- Hundreds of Bookmarklets


## How to use
If you want to use it without caring if GoGuardian can see it
just go to my website: [HolyUnblocked](https://holyunblocked.ttheholyone.repl.co/)
## 
This of course is a great way of using it but if you want to make sure your Teacher can't see the website start by doing this!

- Start by clicking this link [Download](https://replit.com/@TTheHolyOne/holyunblocked.zip ) Because the GITHUB download breaks it

- After doing this all you have to do is open index.html!
