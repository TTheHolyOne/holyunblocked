window._config = {
	"apps": [
		"comms",
		"prxyz",
		"info",
		"conn_stats",
		"hacker-news-tile",
		"sample-games"
	]
}