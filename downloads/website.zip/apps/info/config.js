window.apps["info"] = {};
window.apps["info"]["tile"] = `<div class="box_widget">
	<div>
		<h3>How Holyunblocker works</h3>	
	</div>
	<div>
		<ul class="list">
			<li><a href="apps/info/info.html">Details on HolyUnblocker</a></li>
			<li><a href="apps/info/about.html">Technical HolyUnblocker://about</a></li>
			<li class="italic">(Includes information on system and apps)</li>
		</ul>
	</div>
</div>`;