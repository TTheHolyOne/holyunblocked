window.apps["prxyz"] = {};
window.apps["prxyz"]["tile"] = `<div class="box_widget">
	<div>
		<h3>Pro&zwj;xies</h3>
	</div>
	<div>
		<ul class="list">
			<li>Proxys</li>
			<li style="color:red;">OFFLINE</li>
			<li>open node:
				<select class="btn-inline minize" id="prxyz_select">
					<option>none</option>
					<option>devioustrolling</option>
				</select>
			</li>
		</ul>
	</div>
	<script src="apps/prxyz/tile.js"></script>
</div>`;