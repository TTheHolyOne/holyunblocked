window.apps["hacker-news-tile"] = {};
window.apps["hacker-news-tile"]["tile"] = `<div class="box_widget">
	<div>
		<h3>Hacker News</h3>	
	</div>
	<div>
		<ul class="list">
		<li class="news-item"><a id="news0">Loading...</a></li>
			<li class="news-item"><a id="news1">Loading...</a></li>
			<li class="news-item"><a id="news2">Loading...</a></li>
			<li class="news-item"><a id="news3">Loading...</a></li>
			<li class="news-item"><a id="news4">Loading...</a></li>
		</ul>
	</div>
	<script src="apps/hacker-news-tile/hckr-nws-snppts.js"></script>
</div>`;