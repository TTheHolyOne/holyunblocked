window.apps["sample-games"] = {};
window.apps["sample-games"]["tile"] = `<div class="box_widget">
	<div>
		<h3>Unblocked Games</h3>	
	</div>
	<div>
		<ul class="list">
			<li><a target="_blank" rel="noreferrer noopener" href="apps/sample-games/games.html">Go to games</a></li>
			<li class="italic">(Click left arrow to come back)</li>
		</ul>
	</div>
</div>`;